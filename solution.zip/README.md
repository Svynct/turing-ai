# Turing — Client Take-Home Assessment

Please refer to [README.pdf](README.pdf).
